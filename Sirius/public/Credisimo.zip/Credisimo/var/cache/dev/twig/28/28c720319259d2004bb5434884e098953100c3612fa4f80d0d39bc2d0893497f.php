<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Credisimo/nav.html.twig */
class __TwigTemplate_4e289be71da3739c1f7f5fad0eca210aa35209681624ada7127aa32785368259 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Credisimo/nav.html.twig"));

        // line 1
        echo "    <nav class=\"navbar navbar-expand-sm bg-light navbar-light\">
            <!-- Brand/logo -->
            <a class=\"navbar-brand\" href=\"#\">
              <img class=\"logo-img\" src=\"/img/credissimoLogo.svg\" alt=\"logo\" >
            </a>
            <!-- Links -->
            <div class=\"navbar-nav mr-auto\">
                <ul class=\"navbar-nav mr-auto\">
                    <li class=\"nav-item active\">
                        <a class=\"nav-link\" href =\"/PlusCredit\"> Plus Credit </a>
                    </li>
                    ";
        // line 15
        echo "                    
                </ul>
            </div>
        </nav> 
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Credisimo/nav.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  53 => 15,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("    <nav class=\"navbar navbar-expand-sm bg-light navbar-light\">
            <!-- Brand/logo -->
            <a class=\"navbar-brand\" href=\"#\">
              <img class=\"logo-img\" src=\"/img/credissimoLogo.svg\" alt=\"logo\" >
            </a>
            <!-- Links -->
            <div class=\"navbar-nav mr-auto\">
                <ul class=\"navbar-nav mr-auto\">
                    <li class=\"nav-item active\">
                        <a class=\"nav-link\" href =\"/PlusCredit\"> Plus Credit </a>
                    </li>
                    {#<li class=\"nav-item \">
                        <a class=\"nav-link\" href =\"/products.php\"> Products </a>
                    </li>#}
                    
                </ul>
            </div>
        </nav> 
", "Credisimo/nav.html.twig", "/var/www/testLaminas/laravel/Credisimo/Credisimo/templates/Credisimo/nav.html.twig");
    }
}
