<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Sirius/containerMonth.html.twig */
class __TwigTemplate_dfd132c692b2db5dd43bde8134072d39a6c7838156216bb821e5472f97ba0203 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Sirius/containerMonth.html.twig"));

        // line 1
        echo "    
<div class=\"container\">
    <h1>Schedule list for ";
        // line 3
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 3, $this->source); })()), 1, [], "array", false, false, false, 3), "title", [], "any", false, false, false, 3), "html", null, true);
        echo "</h1>
    <input type=\"hidden\" name=\"onMonthF\" value=\"";
        // line 4
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 4, $this->source); })()), 1, [], "array", false, false, false, 4), "title", [], "any", false, false, false, 4), "html", null, true);
        echo "\">
            <table id=\"table\" >
                <thead>
                    <tr>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" >
                            <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 9, $this->source); })()), 0, [], "array", false, false, false, 9), "onClick", [], "any", false, false, false, 9), "html", null, true);
        echo "\" style=\"text-decoration: none; color:";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 9, $this->source); })()), 0, [], "array", false, false, false, 9), "color", [], "any", false, false, false, 9), "html", null, true);
        echo ";\">
                                <i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i>
                            </a>
                        </th>
                        <th colspan=\"5\" data-field=\"number\" data-halign=\"center\" data-align=\"center\" >
                            ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 14, $this->source); })()), 1, [], "array", false, false, false, 14), "title", [], "any", false, false, false, 14), "html", null, true);
        echo "
                        </th>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" >
                            <a href=\"";
        // line 17
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 17, $this->source); })()), 2, [], "array", false, false, false, 17), "onClick", [], "any", false, false, false, 17), "html", null, true);
        echo "\" style=\"text-decoration: none; color:";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 17, $this->source); })()), 2, [], "array", false, false, false, 17), "color", [], "any", false, false, false, 17), "html", null, true);
        echo ";\">
                                <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                            </a>
                        </th>
                    </tr>
                    <tr>
                        ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["monthHeder"]) || array_key_exists("monthHeder", $context) ? $context["monthHeder"] : (function () { throw new RuntimeError('Variable "monthHeder" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["monthRow"]) {
            // line 24
            echo "                            <th data-field=\"";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\" data-halign=\"center\" data-align=\"center\" >
                                <b >
                                    <span style=\"color:";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["monthRow"], "color", [], "any", false, false, false, 26), "html", null, true);
            echo "\">
                                        ";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["monthRow"], "title", [], "any", false, false, false, 27), "html", null, true);
            echo "
                                    </span>
                                </b>
                            </th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['monthRow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "                    </tr>
                </thead>
                <tbody> 
                    
                    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["daysOfMonth"]) || array_key_exists("daysOfMonth", $context) ? $context["daysOfMonth"] : (function () { throw new RuntimeError('Variable "daysOfMonth" does not exist.', 36, $this->source); })()));
        foreach ($context['_seq'] as $context["weekKey"] => $context["weekRow"]) {
            // line 37
            echo "                        <tr >
                            ";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["weekRow"]);
            foreach ($context['_seq'] as $context["dayKey"] => $context["dayRow"]) {
                // line 39
                echo "                                <td style='";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "backgroundColor", [], "any", false, false, false, 39), "html", null, true);
                echo "'>
                                    <a href=\"#\" onclick=\"openDayModal(";
                // line 40
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "onDay", [], "any", false, false, false, 40), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "onMonth", [], "any", false, false, false, 40), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "onYear", [], "any", false, false, false, 40), "html", null, true);
                echo ", '";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 40, $this->source); })()), 1, [], "array", false, false, false, 40), "title", [], "any", false, false, false, 40), "html", null, true);
                echo "')\">
                                        <span style=\"color:";
                // line 41
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "color", [], "any", false, false, false, 41), "html", null, true);
                echo "; \">
                                            ";
                // line 42
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "title", [], "any", false, false, false, 42), "html", null, true);
                echo "
                                        </span>
                                    </a>
                                </td>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['dayKey'], $context['dayRow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 47
            echo "                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['weekKey'], $context['weekRow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "   
                </tbody>
                
            </table>
            
            
</div>
<!-- The Modal -->
";
        // line 56
        echo twig_include($this->env, $context, "Sirius/dayModal.html.twig");
        echo "
";
        // line 57
        echo twig_include($this->env, $context, "Sirius/appointmentModal.html.twig");
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Sirius/containerMonth.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 57,  172 => 56,  162 => 48,  155 => 47,  144 => 42,  140 => 41,  130 => 40,  125 => 39,  121 => 38,  118 => 37,  114 => 36,  108 => 32,  97 => 27,  93 => 26,  87 => 24,  83 => 23,  72 => 17,  66 => 14,  56 => 9,  48 => 4,  44 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("    
<div class=\"container\">
    <h1>Schedule list for {{ monthThitle[1].title }}</h1>
    <input type=\"hidden\" name=\"onMonthF\" value=\"{{ monthThitle[1].title }}\">
            <table id=\"table\" >
                <thead>
                    <tr>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" >
                            <a href=\"{{monthThitle[0].onClick}}\" style=\"text-decoration: none; color:{{monthThitle[0].color}};\">
                                <i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i>
                            </a>
                        </th>
                        <th colspan=\"5\" data-field=\"number\" data-halign=\"center\" data-align=\"center\" >
                            {{ monthThitle[1].title}}
                        </th>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" >
                            <a href=\"{{monthThitle[2].onClick}}\" style=\"text-decoration: none; color:{{monthThitle[2].color}};\">
                                <i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i>
                            </a>
                        </th>
                    </tr>
                    <tr>
                        {% for key, monthRow in monthHeder %}
                            <th data-field=\"{{ key}}\" data-halign=\"center\" data-align=\"center\" >
                                <b >
                                    <span style=\"color:{{monthRow.color}}\">
                                        {{ monthRow.title}}
                                    </span>
                                </b>
                            </th>
                        {% endfor %}
                    </tr>
                </thead>
                <tbody> 
                    
                    {% for weekKey, weekRow in daysOfMonth %}
                        <tr >
                            {% for dayKey, dayRow in weekRow %}
                                <td style='{{dayRow.backgroundColor}}'>
                                    <a href=\"#\" onclick=\"openDayModal({{ dayRow.onDay }}, {{ dayRow.onMonth }}, {{ dayRow.onYear }}, '{{ monthThitle[1].title}}')\">
                                        <span style=\"color:{{dayRow.color}}; \">
                                            {{ dayRow.title }}
                                        </span>
                                    </a>
                                </td>
                            {% endfor %}
                        </tr>
                    {% endfor %}   
                </tbody>
                
            </table>
            
            
</div>
<!-- The Modal -->
{{ include('Sirius/dayModal.html.twig') }}
{{ include('Sirius/appointmentModal.html.twig') }}
", "Sirius/containerMonth.html.twig", "/var/www/testLaminas/laravel/Sirius/Sirius/templates/Sirius/containerMonth.html.twig");
    }
}
