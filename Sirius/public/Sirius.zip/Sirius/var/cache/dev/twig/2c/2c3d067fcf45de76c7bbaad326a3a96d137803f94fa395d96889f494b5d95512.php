<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Sirius/dayModal.html.twig */
class __TwigTemplate_4ca200dacb5343d76fde0f56fa95a839252482b6dd760ffee8772a96dd67f8ab extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Sirius/dayModal.html.twig"));

        // line 1
        echo "<!-- The Modal -->
<div class=\"modal\" id=\"dayModal\">
    <div class=\"modal-dialog modal-xl\">
        <div class=\"modal-content\">
            <form name=\"edit\">    
                <!-- Modal Header -->
                <div class=\"modal-header\">
                    <h3 class=\"modal-title\"></h3>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                </div>
                <!-- Modal body -->
                
                <div class=\"modal-body\">
                    <div class=\"form-group\">
                        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["scheduleOfDay"]) || array_key_exists("scheduleOfDay", $context) ? $context["scheduleOfDay"] : (function () { throw new RuntimeError('Variable "scheduleOfDay" does not exist.', 15, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["dayRow"]) {
            // line 16
            echo "                            <div class=\"row\">
                                <div class=\"col-sm-2 text-right\">
                                </div>
                                <div class=\"col-sm-4\">
                                    <button type=\"button\" onclick='editUser()' class=\"btn btn-outline-secondary form-control disabled\" data-dismiss=\"save\">";
            // line 20
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["dayRow"], 1, [], "array", false, false, false, 20), "title", [], "any", false, false, false, 20), "html", null, true);
            echo "</button>
                                </div>    
                                <div class=\"col-sm-4\">
                                    <button type=\"button\" onclick='editUser()' class=\"btn btn-outline-secondary form-control disabled\" data-dismiss=\"save\">";
            // line 23
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["dayRow"], 2, [], "array", false, false, false, 23), "title", [], "any", false, false, false, 23), "html", null, true);
            echo "</button>
                                </div>    
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['dayRow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 26
        echo "    
                    </div>
                </div>
                <!-- Modal footer -->
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Sirius/dayModal.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 26,  72 => 23,  66 => 20,  60 => 16,  56 => 15,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- The Modal -->
<div class=\"modal\" id=\"dayModal\">
    <div class=\"modal-dialog modal-xl\">
        <div class=\"modal-content\">
            <form name=\"edit\">    
                <!-- Modal Header -->
                <div class=\"modal-header\">
                    <h3 class=\"modal-title\"></h3>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                </div>
                <!-- Modal body -->
                
                <div class=\"modal-body\">
                    <div class=\"form-group\">
                        {% for key, dayRow in scheduleOfDay %}
                            <div class=\"row\">
                                <div class=\"col-sm-2 text-right\">
                                </div>
                                <div class=\"col-sm-4\">
                                    <button type=\"button\" onclick='editUser()' class=\"btn btn-outline-secondary form-control disabled\" data-dismiss=\"save\">{{dayRow[1].title}}</button>
                                </div>    
                                <div class=\"col-sm-4\">
                                    <button type=\"button\" onclick='editUser()' class=\"btn btn-outline-secondary form-control disabled\" data-dismiss=\"save\">{{dayRow[2].title}}</button>
                                </div>    
                            </div>
                        {% endfor %}    
                    </div>
                </div>
                <!-- Modal footer -->
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>", "Sirius/dayModal.html.twig", "/var/www/testLaminas/laravel/Sirius/Sirius/templates/Sirius/dayModal.html.twig");
    }
}
