<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Sirius/containerMonth.html.twig */
class __TwigTemplate_23579ae9f5467f318066c702164749a9c16b54b480c6838d02eb6a08a1e50627 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Sirius/containerMonth.html.twig"));

        // line 1
        echo "    
<div class=\"container\">
    <h1>Schedule list for ";
        // line 3
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 3, $this->source); })()), 1, [], "array", false, false, false, 3), "title", [], "any", false, false, false, 3), "html", null, true);
        echo "</h1>
    
            
    <!--data-ajax=\"ajaxRequest\"
    data-side-pagination=\"server\"
    data-show-search-clear-button=\"true\"
        data-show-columns=\"true\"
                data-show-columns-toggle-all=\"true\"
                data-pagination=\"true\"
                data-page-list=\"[5, 10, 25, 50, 100, all]\"
    -->
            <table
                id=\"table\"
            >
                <thead>
                    <tr>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" ><i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i></th>
                        <th colspan=\"5\" data-field=\"number\" data-halign=\"center\" data-align=\"center\" >";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 20, $this->source); })()), 1, [], "array", false, false, false, 20), "title", [], "any", false, false, false, 20), "html", null, true);
        echo "</th>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" ><i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></th>
                    </tr>
                    <tr>
                        ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["monthHeder"]) || array_key_exists("monthHeder", $context) ? $context["monthHeder"] : (function () { throw new RuntimeError('Variable "monthHeder" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["monthRow"]) {
            // line 25
            echo "                            <th data-field=\"";
            echo twig_escape_filter($this->env, $context["key"], "html", null, true);
            echo "\" data-halign=\"center\" data-align=\"center\" >
                                <b>
                                    <span style=\"color:";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["monthRow"], "color", [], "any", false, false, false, 27), "html", null, true);
            echo "\">
                                        ";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["monthRow"], "title", [], "any", false, false, false, 28), "html", null, true);
            echo "
                                    </span>
                                </b>
                            </th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['monthRow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "                    </tr>
                </thead>
                <tbody> 
                    
                    ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["daysOfMonth"]) || array_key_exists("daysOfMonth", $context) ? $context["daysOfMonth"] : (function () { throw new RuntimeError('Variable "daysOfMonth" does not exist.', 37, $this->source); })()));
        foreach ($context['_seq'] as $context["weekKey"] => $context["weekRow"]) {
            // line 38
            echo "                        <tr >
                            ";
            // line 39
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["weekRow"]);
            foreach ($context['_seq'] as $context["dayKey"] => $context["dayRow"]) {
                // line 40
                echo "                                <td>
                                    <a href=\"#\" onclick=\"openDayModal(";
                // line 41
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "onDay", [], "any", false, false, false, 41), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "onMonth", [], "any", false, false, false, 41), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "onYear", [], "any", false, false, false, 41), "html", null, true);
                echo ", '";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["monthThitle"]) || array_key_exists("monthThitle", $context) ? $context["monthThitle"] : (function () { throw new RuntimeError('Variable "monthThitle" does not exist.', 41, $this->source); })()), 1, [], "array", false, false, false, 41), "title", [], "any", false, false, false, 41), "html", null, true);
                echo "')\">
                                    <span style=\"color:";
                // line 42
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "color", [], "any", false, false, false, 42), "html", null, true);
                echo "\">
                                        ";
                // line 43
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["dayRow"], "title", [], "any", false, false, false, 43), "html", null, true);
                echo "
                                    </span>
                                    </a>
                                </td>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['dayKey'], $context['dayRow'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 48
            echo "                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['weekKey'], $context['weekRow'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "   
                </tbody>
                
            </table>
            
            
</div>
<!-- The Modal -->
";
        // line 57
        echo twig_include($this->env, $context, "Sirius/dayModal.html.twig");
        echo "                
<script>
    \$(function() {
        \$('#table').bootstrapTable()
    })
function openDayModal(onDay, onMonth, onYear, onMonthF ) {
    if ( onDay == 0)
    {
        alert('It is not working Day.  ')
    }
    else {
        console.log(onDay);
        \$(\"#dayModal\").modal();
        \$(\".modal-title\").text('Schedule list for ' + onDay + ' - ' + onMonthF + ' - ' + onYear);
        var postData = {
            onDay: onDay,
            onMonth: onMonth,
            onYear: onYear,
        };
        \$.ajax({
            url: \"/openDayModal\",
            type:\"POST\",
            dataType: 'JSON',
            data: postData,
            success:function(response){
                //console.log(response.requestData);Price_EndUser_LV_wo_VAT
                if(response.success == 1) {

                }
                else{
                    //alert(response.error);
                }
            },
            error:function(response){
                console.log('error',response);
                if(response) {
                }
            },
        });
    }
    
}
    
</script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Sirius/containerMonth.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 57,  148 => 49,  141 => 48,  130 => 43,  126 => 42,  116 => 41,  113 => 40,  109 => 39,  106 => 38,  102 => 37,  96 => 33,  85 => 28,  81 => 27,  75 => 25,  71 => 24,  64 => 20,  44 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("    
<div class=\"container\">
    <h1>Schedule list for {{ monthThitle[1].title }}</h1>
    
            
    <!--data-ajax=\"ajaxRequest\"
    data-side-pagination=\"server\"
    data-show-search-clear-button=\"true\"
        data-show-columns=\"true\"
                data-show-columns-toggle-all=\"true\"
                data-pagination=\"true\"
                data-page-list=\"[5, 10, 25, 50, 100, all]\"
    -->
            <table
                id=\"table\"
            >
                <thead>
                    <tr>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" ><i class=\"fa fa-angle-left\" aria-hidden=\"true\"></i></th>
                        <th colspan=\"5\" data-field=\"number\" data-halign=\"center\" data-align=\"center\" >{{ monthThitle[1].title}}</th>
                        <th data-field=\"number\" data-halign=\"center\" data-align=\"center\" ><i class=\"fa fa-angle-right\" aria-hidden=\"true\"></i></th>
                    </tr>
                    <tr>
                        {% for key, monthRow in monthHeder %}
                            <th data-field=\"{{ key}}\" data-halign=\"center\" data-align=\"center\" >
                                <b>
                                    <span style=\"color:{{monthRow.color}}\">
                                        {{ monthRow.title}}
                                    </span>
                                </b>
                            </th>
                        {% endfor %}
                    </tr>
                </thead>
                <tbody> 
                    
                    {% for weekKey, weekRow in daysOfMonth %}
                        <tr >
                            {% for dayKey, dayRow in weekRow %}
                                <td>
                                    <a href=\"#\" onclick=\"openDayModal({{ dayRow.onDay }}, {{ dayRow.onMonth }}, {{ dayRow.onYear }}, '{{ monthThitle[1].title}}')\">
                                    <span style=\"color:{{dayRow.color}}\">
                                        {{ dayRow.title }}
                                    </span>
                                    </a>
                                </td>
                            {% endfor %}
                        </tr>
                    {% endfor %}   
                </tbody>
                
            </table>
            
            
</div>
<!-- The Modal -->
{{ include('Sirius/dayModal.html.twig') }}                
<script>
    \$(function() {
        \$('#table').bootstrapTable()
    })
function openDayModal(onDay, onMonth, onYear, onMonthF ) {
    if ( onDay == 0)
    {
        alert('It is not working Day.  ')
    }
    else {
        console.log(onDay);
        \$(\"#dayModal\").modal();
        \$(\".modal-title\").text('Schedule list for ' + onDay + ' - ' + onMonthF + ' - ' + onYear);
        var postData = {
            onDay: onDay,
            onMonth: onMonth,
            onYear: onYear,
        };
        \$.ajax({
            url: \"/openDayModal\",
            type:\"POST\",
            dataType: 'JSON',
            data: postData,
            success:function(response){
                //console.log(response.requestData);Price_EndUser_LV_wo_VAT
                if(response.success == 1) {

                }
                else{
                    //alert(response.error);
                }
            },
            error:function(response){
                console.log('error',response);
                if(response) {
                }
            },
        });
    }
    
}
    
</script>", "Sirius/containerMonth.html.twig", "/var/www/testLaminas/laravel/Sirius/Sirius/templates/Sirius/containerMonth.html.twig");
    }
}
