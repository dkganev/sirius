<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Sirius/appointmentModal.html.twig */
class __TwigTemplate_5768abbaf8d280757f859264faf2e48dc6ceb8601ec0e2d0d6dbd691d8839545 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Sirius/appointmentModal.html.twig"));

        // line 1
        echo "<!-- The Modal -->
<div class=\"modal\" id=\"appointmentModal\">
    <div class=\"modal-dialog modal-xl\">
        <div class=\"modal-content\">
            <form name=\"appointment\" id=\"appointment\" onsubmit=\"return validateMyForm();\" method=\"POST\">    
                <!-- Modal Header -->
                <div class=\"modal-header\">
                    <h3 class=\"modal-title appointmentModal-title\"></h3>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                </div>
                <!-- Modal body -->
                
                <input type=\"hidden\" name=\"onDay\" id='inputOnDay' value=\"\" >
                <input type=\"hidden\" name=\"onTitle\" id='inputOnTitle' value=\"\" >
                <input type=\"hidden\" name=\"onMonth\" value=\"";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["daysOfMonth"]) || array_key_exists("daysOfMonth", $context) ? $context["daysOfMonth"] : (function () { throw new RuntimeError('Variable "daysOfMonth" does not exist.', 15, $this->source); })()), 2, [], "array", false, false, false, 15), 9, [], "array", false, false, false, 15), "onMonth", [], "any", false, false, false, 15), "html", null, true);
        echo "\">
                <input type=\"hidden\" name=\"onYear\" value=\"";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["daysOfMonth"]) || array_key_exists("daysOfMonth", $context) ? $context["daysOfMonth"] : (function () { throw new RuntimeError('Variable "daysOfMonth" does not exist.', 16, $this->source); })()), 2, [], "array", false, false, false, 16), 9, [], "array", false, false, false, 16), "onYear", [], "any", false, false, false, 16), "html", null, true);
        echo "\">
                                                                
                <div class=\"modal-body\">
                    <div class=\"form-group\">
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    First Name:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> First Name.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"text\" name=\"first_name\" placeholder=\"First Name\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    Last Name:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> Last Name.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"text\" name=\"last_name\" placeholder=\"Last Name\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    E-Mail:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> E-Mail.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"email\" name=\"email\"  placeholder=\"E-Mail\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    Phone:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> Phone.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"phone\" name=\"phone\"  placeholder=\"Phone\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                </div>
                <!-- Modal footer -->
                <div class=\"modal-footer\">
                    <input type=\"submit\" class=\"btn btn-info \" value=\"Submit\">
                    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Sirius/appointmentModal.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 16,  56 => 15,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- The Modal -->
<div class=\"modal\" id=\"appointmentModal\">
    <div class=\"modal-dialog modal-xl\">
        <div class=\"modal-content\">
            <form name=\"appointment\" id=\"appointment\" onsubmit=\"return validateMyForm();\" method=\"POST\">    
                <!-- Modal Header -->
                <div class=\"modal-header\">
                    <h3 class=\"modal-title appointmentModal-title\"></h3>
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\">&times;</button>
                </div>
                <!-- Modal body -->
                
                <input type=\"hidden\" name=\"onDay\" id='inputOnDay' value=\"\" >
                <input type=\"hidden\" name=\"onTitle\" id='inputOnTitle' value=\"\" >
                <input type=\"hidden\" name=\"onMonth\" value=\"{{ daysOfMonth[2][9].onMonth }}\">
                <input type=\"hidden\" name=\"onYear\" value=\"{{ daysOfMonth[2][9].onYear }}\">
                                                                
                <div class=\"modal-body\">
                    <div class=\"form-group\">
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    First Name:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> First Name.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"text\" name=\"first_name\" placeholder=\"First Name\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    Last Name:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> Last Name.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"text\" name=\"last_name\" placeholder=\"Last Name\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    E-Mail:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> E-Mail.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"email\" name=\"email\"  placeholder=\"E-Mail\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                        <div class=\"row\">
                            <div class=\"col-sm-4 text-right\">
                                <label>
                                    <sup><i class=\"fa fa-asterisk\" style=\"font-size: 10px; \"></i></sup>
                                    Phone:<br/>
                                    <span style=\"font-size: 0.85em;font-style: italic;color: #666;\"> Phone.</span>
                                </label>
                            </div>
                            <div class=\"col-sm-4\">
                                <div class=\"input-group mb-3\">
                                    <input class=\"form-control\" type=\"phone\" name=\"phone\"  placeholder=\"Phone\"  value=\"\" required>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                </div>
                <!-- Modal footer -->
                <div class=\"modal-footer\">
                    <input type=\"submit\" class=\"btn btn-info \" value=\"Submit\">
                    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>", "Sirius/appointmentModal.html.twig", "/var/www/testLaminas/laravel/Sirius/Sirius/templates/Sirius/appointmentModal.html.twig");
    }
}
