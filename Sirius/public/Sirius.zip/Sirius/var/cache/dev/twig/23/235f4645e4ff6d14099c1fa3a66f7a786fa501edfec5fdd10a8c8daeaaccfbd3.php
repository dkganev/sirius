<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Sirius/nav.html.twig */
class __TwigTemplate_2485345b2a4a80e374216546afae0d033b6bd8cd2663e92d70a8f110be82701f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Sirius/nav.html.twig"));

        // line 1
        echo "    <nav class=\"navbar navbar-expand-sm bg-light navbar-light\">
            <!-- Brand/logo -->
            <a class=\"navbar-brand\" href=\"#\">
              <img class=\"logo-img\" src=\"/img/logo.png\" alt=\"logo\" >
            </a>
            <!-- Links -->
            <div class=\"navbar-nav mr-auto\">
                <ul class=\"navbar-nav mr-auto\">
                    <li class=\"nav-item active\">
                        <a class=\"nav-link\" href =\"/Schedule\"> Schedule </a>
                    </li>
                    ";
        // line 15
        echo "                    
                </ul>
            </div>
        </nav> 
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Sirius/nav.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  53 => 15,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("    <nav class=\"navbar navbar-expand-sm bg-light navbar-light\">
            <!-- Brand/logo -->
            <a class=\"navbar-brand\" href=\"#\">
              <img class=\"logo-img\" src=\"/img/logo.png\" alt=\"logo\" >
            </a>
            <!-- Links -->
            <div class=\"navbar-nav mr-auto\">
                <ul class=\"navbar-nav mr-auto\">
                    <li class=\"nav-item active\">
                        <a class=\"nav-link\" href =\"/Schedule\"> Schedule </a>
                    </li>
                    {#<li class=\"nav-item \">
                        <a class=\"nav-link\" href =\"\"> </a>
                    </li>#}
                    
                </ul>
            </div>
        </nav> 
", "Sirius/nav.html.twig", "/var/www/testLaminas/laravel/Sirius/Sirius/templates/Sirius/nav.html.twig");
    }
}
