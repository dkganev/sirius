<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* Credisimo/containerPlusCreditList.html.twig */
class __TwigTemplate_d5ddda993c5f14157ccd65be10a098e248283d3a853329752bbac95bcd891346 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "Credisimo/containerPlusCreditList.html.twig"));

        // line 1
        echo "    
<div class=\"container\">
    <h1>Plus Credit List</h1>
    
            
    <!--data-ajax=\"ajaxRequest\"
    data-side-pagination=\"server\"
    data-show-search-clear-button=\"true\"
    -->
            <table
                id=\"table\"
                data-show-columns=\"true\"
                data-show-columns-toggle-all=\"true\"
                data-pagination=\"true\"
                data-page-list=\"[5, 10, 25, 50, 100, all]\"
            >
                <thead>
                    <tr>
                        <th data-field=\"number\" >N</th>
                        <th data-field=\"date\" >Date</th>
                        <th data-field=\"period\" >Period</th>
                        <th data-field=\"installmentAmount\" >Installment Amount</th>
                        <th data-field=\"principal\" >Principal</th>
                        
                        <th data-field=\"interest\" >Interest</th>
                        <th data-field=\"tax1\" >Tax 1</th>
                        <th data-field=\"tax2\" >Tax 2</th>
                    </tr>
                </thead>
                <tbody> 
                    ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["paramsLists"]) || array_key_exists("paramsLists", $context) ? $context["paramsLists"] : (function () { throw new RuntimeError('Variable "paramsLists" does not exist.', 31, $this->source); })()));
        foreach ($context['_seq'] as $context["key"] => $context["paramsList"]) {
            // line 32
            echo "                        <tr>
                            <td  >";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "number", [], "any", false, false, false, 33), "html", null, true);
            echo "</td>
                            <td  >";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "date", [], "any", false, false, false, 34), "html", null, true);
            echo "</td>
                            <td  >";
            // line 35
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "period", [], "any", false, false, false, 35), "html", null, true);
            echo "</td>
                            <td  >";
            // line 36
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "installmentAmount", [], "any", false, false, false, 36), "html", null, true);
            echo "</td>
                            <td  >";
            // line 37
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "principal", [], "any", false, false, false, 37), "html", null, true);
            echo "</td>

                            <td  >";
            // line 39
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "interest", [], "any", false, false, false, 39), "html", null, true);
            echo "</td>
                            <td  >";
            // line 40
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "tax1", [], "any", false, false, false, 40), "html", null, true);
            echo "</td>
                            <td  >";
            // line 41
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["paramsList"], "tax2", [], "any", false, false, false, 41), "html", null, true);
            echo "</td>
                        
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['paramsList'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        echo "                </tbody>
                
            </table>
      
</div>
<script>
\$(function() {
    \$('#table').bootstrapTable()
})

    
</script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "Credisimo/containerPlusCreditList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  118 => 45,  108 => 41,  104 => 40,  100 => 39,  95 => 37,  91 => 36,  87 => 35,  83 => 34,  79 => 33,  76 => 32,  72 => 31,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("    
<div class=\"container\">
    <h1>Plus Credit List</h1>
    
            
    <!--data-ajax=\"ajaxRequest\"
    data-side-pagination=\"server\"
    data-show-search-clear-button=\"true\"
    -->
            <table
                id=\"table\"
                data-show-columns=\"true\"
                data-show-columns-toggle-all=\"true\"
                data-pagination=\"true\"
                data-page-list=\"[5, 10, 25, 50, 100, all]\"
            >
                <thead>
                    <tr>
                        <th data-field=\"number\" >N</th>
                        <th data-field=\"date\" >Date</th>
                        <th data-field=\"period\" >Period</th>
                        <th data-field=\"installmentAmount\" >Installment Amount</th>
                        <th data-field=\"principal\" >Principal</th>
                        
                        <th data-field=\"interest\" >Interest</th>
                        <th data-field=\"tax1\" >Tax 1</th>
                        <th data-field=\"tax2\" >Tax 2</th>
                    </tr>
                </thead>
                <tbody> 
                    {% for key, paramsList in paramsLists %}
                        <tr>
                            <td  >{{ paramsList.number }}</td>
                            <td  >{{ paramsList.date }}</td>
                            <td  >{{ paramsList.period }}</td>
                            <td  >{{ paramsList.installmentAmount }}</td>
                            <td  >{{ paramsList.principal }}</td>

                            <td  >{{ paramsList.interest }}</td>
                            <td  >{{ paramsList.tax1 }}</td>
                            <td  >{{ paramsList.tax2 }}</td>
                        
                        </tr>
                    {% endfor %}
                </tbody>
                
            </table>
      
</div>
<script>
\$(function() {
    \$('#table').bootstrapTable()
})

    
</script>", "Credisimo/containerPlusCreditList.html.twig", "/var/www/testLaminas/laravel/Credisimo/Credisimo/templates/Credisimo/containerPlusCreditList.html.twig");
    }
}
