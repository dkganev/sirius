<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'index', '_controller' => 'App\\Controller\\Schedule::Index'], null, ['GET' => 0], null, false, false, null]],
        '/Schedule' => [
            [['_route' => 'Schedule', '_controller' => 'App\\Controller\\Schedule::Index'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'SchedulePost', '_controller' => 'App\\Controller\\Schedule::Index'], null, ['POST' => 0], null, false, false, null],
        ],
        '/openDayModal' => [[['_route' => 'openDayModal', '_controller' => 'App\\Controller\\Schedule::openDayModal'], null, ['POST' => 0], null, false, false, null]],
        '/saveAppointmentForm' => [[['_route' => 'saveAppointmentForm', '_controller' => 'App\\Controller\\Schedule::saveAppointmentForm'], null, ['POST' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        35 => [
            [['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
